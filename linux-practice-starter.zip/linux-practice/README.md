# Linux Programming Practice

C programs for practising Linux process management and inter-process communication.

## Process management

- `process_management/parent_wait_multiple.c` — creates three child processes and collects each child's exit status with `waitpid()`.
- `process_management/orphan_process.c` — demonstrates an orphan process after its parent terminates.
- `process_management/zombie_process.c` — demonstrates a zombie process and then reaps it with `waitpid()`.

## Inter-process communication

- `pipes/two_pipes.c` — parent sends a message to the child through one pipe; the child converts it to uppercase and sends it back through a second pipe.

## Compile and run

Run these commands from the repository root:

```bash
gcc process_management/parent_wait_multiple.c -o parent_wait_multiple
./parent_wait_multiple

gcc process_management/orphan_process.c -o orphan_process
./orphan_process

gcc process_management/zombie_process.c -o zombie_process
./zombie_process

gcc pipes/two_pipes.c -o two_pipes
./two_pipes
```

## Note

These are Linux practice programs. Check your organization's rules before uploading or cloning code through a personal GitHub/GitLab account or a company server.
